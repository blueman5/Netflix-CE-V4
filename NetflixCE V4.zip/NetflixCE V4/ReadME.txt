--Problems--
Join our discord server to fix problems/errors.

--OMGExploits--
discord.gg/rblxhacks

--How to use--
1. Open the FPS Unlocker and change the Unlock Method to "Flag Files" (right click the icon).
2. Open Roblox, Web or UWP
3. Join our teleporter (in description of video or inside our discord server)
4. Choose a game to continue.
5. Choose Injection method (for toolless have to reset character or die)
6. Enjoy!

